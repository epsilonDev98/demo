const bcrypt = require("bcryptjs");
var passport = require("passport");
var CryptoJS = require("crypto-js");
const multer = require('multer');
//added
const upload = multer({ dest: 'uploads/' });
const db = require("../db/db");
//requiring path and fs modules
const dotenv = require("dotenv"); /****imp env variables */
dotenv.config({ path: "./.env" });
const path = require("path");
const fs = require("fs");
var _ = require("lodash");
const { stringify } = require("querystring");
const { concat } = require("lodash");
const { log } = require("async");

//joining path of directory

/*****Login function called as a method of authController */
exports.login = async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).render("login", {
                message: "Please provide Email and Password",
            });
        }

        const results = await db.query("SELECT * FROM users WHERE email = $1", [
            email,
        ]);

        if (!results[0]) {
            return res.status(400).render("login", {
                message: "Please Register Before trying to Log In!",
            });
        }

        const user = results[0];

        //   if (!(await bcrypt.compare(password, user.password))) {
        //     return res.status(401).render("login", {
        //       message: "Invalid Email/Password",
        //     });
        //   }

        req.logIn(user, function (err) {
            if (err) {
                return console.error(err);
            }

            if (user.email === "sarvesh@iisc.ac.in") {
                res.redirect("/adminportal");
            } else {
                console.log("login redirect");
                res.redirect("/");
            }
        });
    } catch (error) {
        console.log(error);
    }
};

/*****Register function called as a method of authController */
// exports.register = (req, res) => {
//   console.log(req.body);

//   const { name, email, password, passwordConfirm } = req.body;

//   db.query(
//     "SELECT email FROM users WHERE email= ?",
//     [email],
//     async (error, results) => {
//       if (error) {
//         console.log(error);
//       }
//       if (results.length > 0) {
//         return res.render("register", {
//           message: "That email has been already registered",
//         });
//       } else if (password !== passwordConfirm) {
//         return res.render("register", {
//           message: "Passwords do not match",
//         });
//       }

//       let hashedPassword = await bcrypt.hash(password, 8);
//       console.log(hashedPassword);

//       db.query(
//         "SELECT * FROM users WHERE email IS NULL",
//         async (error, results) => {
//           if (error) {
//             console.log(error);
//           } else {
//             var userid = results[0].id;
//             db.query(
//               "UPDATE users SET `name` = ?, `email` = ?, `password` = ? WHERE id=?",
//               [name, email, hashedPassword, userid],
//               async (error, results) => {
//                 if (error) {
//                   console.log(error);
//                 } else {
//                   return res.render("register", {
//                     message: "Registration Successful",
//                   });
//                 }
//               }
//             );
//           }
//         }
//       );
//     }
//   );
// };

exports.register = async (req, res) => {
    try {
        const { name, email, password, passwordConfirm } = req.body;

        // Check if email is already registered
        const [existingUser] = await db.query(
            "SELECT email FROM users WHERE email = $1",
            [email]
        );

        if (existingUser) {
            return res.render("register", {
                message: "That email has already been registered",
            });
        }

        // Check if passwords match
        if (password !== passwordConfirm) {
            return res.render("register", {
                message: "Passwords do not match",
            });
        }

        // Hash the password
        const hashedPassword = await bcrypt.hash(password, 8);

        // Find a user with a null email (assuming this is the case for a new user)
        const [results] = await db.query("SELECT * FROM users WHERE email IS NULL");

        if (!results || results.length === 0) {
            return res.status(500).send("Unexpected error occurred.");
        }

        const userid = results[0].id;

        // Update the user with the provided information
        await db.query(
            "UPDATE users SET `name` = $1, `email` = $2, `password` = $3 WHERE id = $4",
            [name, email, hashedPassword, userid]
        );

        return res.render("register", {
            message: "Registration Successful",
        });
    } catch (error) {
        console.error(error);
        return res.status(500).send("Internal Server Error");
    }
};

passport.serializeUser(function (user_id, done) {
    done(null, user_id);
});

passport.deserializeUser(function (user_id, done) {
    done(null, user_id);
});

exports.startss = async (req, res) => {
    if (req.isAuthenticated) {
        var email = req.session.passport.user;
        try {
            const results = await db.oneOrNone(
                "SELECT * FROM users WHERE email = $1",
                [email]
            );

            if (results) {
                if (results.consent_form == null) {
                    res.redirect("/subjectinfo");
                } else {
                    res.redirect("/discalproc");
                }
            } else {
                res.render("login", {
                    message: "Please login to Access this page!",
                });
            }
        } catch (error) {
            console.error(error);
            // Handle the error here
        }
    } else {
        res.render("login", {
            message: "Please login to Access this page!",
        });
    }
};

exports.consent = async (req, res) => {
    if (req.isAuthenticated) {
        console.log("/conset", req.session.passport.user);
        var email = req.session.passport.user;
        // id = id[1];
        try {
            const csf = JSON.stringify(req.body);
            console.log("csf::", JSON.stringify(csf));
            // Update the consent_form
            await db.none("UPDATE users SET consent_form = $1 WHERE email = $2", [
                csf,
                email,
            ]);
            res.redirect("/discalproc");
        } catch (error) {
            console.error(error);
            // Handle the error here
        }
    } else {
        res.render("login", {
            message: "Please login to Access this page!",
        });
    }
};

exports.ssd = async (req, res) => {
    if (req.isAuthenticated) {
        try {
            const email = req.session.passport.user;
            const adu = JSON.stringify(req.body);
            console.log("ssd::adu", adu, "\n email", email);
            const results = await db.oneOrNone('SELECT * FROM users WHERE email=$1', [email]);
            if (results) {
                await db.none('UPDATE users SET ADD_SUBJECT_DETAILS = $1 WHERE email = $2', [adu, email])
                console.log("ssd::studyinterface redirected to study interface");
                res.redirect("/studyinterface");
            } else {
                console.log('user not found');
            }
        } catch (error) {
            console.log(error);
        }
    } else {
        res.render("login", {
            message: "Please login to Access this page!",
        });
    }
};

exports.getfirstsessionlist = (req, res) => {
    res.redirect("/firstsession");
};
exports.getsecondsessionlist = async (req, res) => {
    if (req.isAuthenticated) {
        try {
            const email = req.session.passport.user;
            const user = await db.oneOrNone('SELECT * FROM users WHERE email = $1', [email]);
            console.log("getsecondsessionlist::user::email", user, email);
            if (user) {
                const imglist = JSON.parse(user.IMAGE_LIST);
                const fslist = imglist.FIRST_SESSION_IMAGE_LIST;

                const unseen_img_list = [];
                for (const i in _.range(Object.entries(fslist).length)) {
                    if (fslist[i].seen_status == 0) {
                        unseen_img_list.push(fslist[i].image_name);
                    }
                }

                if (unseen_img_list.length > 0) {
                    console.log("getsecondsessionlist::studyinterface");
                    res.redirect('/studyinterface');
                } else {
                    console.log("getsecondsessionlist::secondsession");
                    res.redirect('/secondsession');
                }
            } else {
                console.log('User not found');
            }
        } catch (error) {
            console.log(error);
        }
    } else {
        res.render("login", {
            message: "Please login to Access this page!",
        });
    }
};

exports.nexttl1img = async (req, res) => {
    if (req.isAuthenticated) {
        var email = req.session.passport.user;
        // console.log(req.body);
        var image_name = req.body.image_name;
        if (image_name.includes("\\")) {
            image_name = image_name.split("\\")[1];
        }

        var rating = req.body.rating;
        // var comment = req.body.comment;

        // console.log(image_name);
        // console.log(rating);
        try {
            const user = await db.oneOrNone('SELECT * FROM users WHERE email = $1', [email]);

            if (user) {
                const unseen_tl_list = [];
                const imglist = user.IMAGE_LIST;

                const fslist = imglist.FIRST_SESSION_IMAGE_LIST;
                const sslist = imglist.SECOND_SESSION_IMAGE_LIST;
                const tlist = imglist.TRAINING_IMAGE_LIST;

                let index = null;

                for (const i in _.range(Object.entries(tlist).length)) {
                    if (tlist[i].image_name == image_name) {
                        index = i;
                    }

                    if (tlist[i].rating == -99) {
                        unseen_tl_list.push(tlist[i].image_name);
                    }
                }

                if (index !== null && tlist[index].rating == -99) {
                    tlist[index].rating = rating;
                    tlist[index].seen_status = 1;

                    const Firstsessionobj = _.extend({}, fslist);
                    const trainingobj = _.extend({}, tlist);
                    const Secondsessionobj = _.extend({}, sslist);

                    const upimglist = JSON.stringify({
                        TRAINING_IMAGE_LIST: trainingobj,
                        FIRST_SESSION_IMAGE_LIST: Firstsessionobj,
                        SECOND_SESSION_IMAGE_LIST: Secondsessionobj,
                    });

                    await db.none('UPDATE users SET IMAGE_LIST = $1 WHERE email = $2', [upimglist, email]);
                }

                if (unseen_tl_list.length > 1) {
                    const file = unseen_tl_list[1];
                    const trainingcomobj = {
                        0: {
                            image_name: "00023_00_0.04s.png",
                            trainingcomment:
                                "This looks picture perfect, with perceptually no significant distortions! How much would you rate it?",
                        },
                        1: {
                            image_name: "10161_00_10s_SID_GT_autobrightoff.png",
                            trainingcomment:
                                "The top right and bottom right portions of the image seem a bit blurred , don't they? Move the slider and click Next to tell us how much you would rate it!",
                        },
                        2: {
                            image_name: "FUJI_10161_00_0.1s.png",
                            trainingcomment: "Looks Blurred , isn't it so?",
                        },
                        3: {
                            image_name: "FUJI_10161_00_0.1s_DIDN_he.png",
                            trainingcomment:
                                "This looks sharper as compared to the previous one , but colours seem to off! What do you think?",
                        },
                        4: {
                            image_name: "FUJI_10174_00_0.1s.png",
                            trainingcomment:
                                "Okay ,here we can actually witness what heavy noise can do to your image! It has even ruined the Color quality of the image ",
                        },
                        5: {
                            image_name: "FUJI_10174_00_0.1s_DIDN_ldr.png",
                            trainingcomment:
                                "Though it's a color image, contrast saturation is making it look as though it is grayscale!",
                        },
                        6: {
                            image_name: "SONY_00002_00_0.1s_matlabHEon3.png",
                            trainingcomment: "This is what over enhancement looks like!",
                        },
                        7: {
                            image_name: "SONY_10087_00_0.1s_DIDN_ldr.png",
                            trainingcomment:
                                "Can't see much? Well this is an example of under enhancement!",
                        },
                    };

                    let tempcom = "";

                    for (const i in _.range(Object.entries(trainingcomobj).length)) {
                        if (trainingcomobj[i].image_name.includes(String(file))) {
                            tempcom += trainingcomobj[i].trainingcomment;
                        }
                    }

                    const send = "\\" + file + "comment:" + tempcom;
                    const encrypted = CryptoJS.AES.encrypt(send, "doesntmatterifyouknowit");

                    res.redirect("/trainingphase1?message=" + encodeURIComponent(encrypted));
                } else {
                    res.redirect("/firstsession");
                }
            } else {
                console.log('User not found');
            }
        } catch (error) {
            console.log(error);
        }
    } else {
        res.render("login", {
            message: "Please login to Access this page!",
        });
    }
};

exports.nexttl2img = async (req, res) => {
    if (req.isAuthenticated) {
        const email = req.session.passport.user;
        // console.log(req.body);
        const image_name = req.body.image_name;
        if (image_name.includes("\\")) {
            image_name = image_name.split("\\")[1];
        }

        const rating = req.body.rating;
        // console.log(image_name);
        // console.log(rating);
        try {
            const user = await db.oneOrNone('SELECT * FROM users WHERE email = $1', [email]);

            if (user) {
                const unseen_tl_list = [];
                const imglist = JSON.parse(user.IMAGE_LIST);

                const fslist = imglist.FIRST_SESSION_IMAGE_LIST;
                const sslist = imglist.SECOND_SESSION_IMAGE_LIST;
                const tlist = imglist.TRAINING_IMAGE_LIST;

                let index = null;

                for (const i in _.range(Object.entries(tlist).length)) {
                    if (tlist[i].image_name == image_name) {
                        index = i;
                    }

                    if (tlist[i].rating_2 == -99) {
                        unseen_tl_list.push(tlist[i].image_name);
                    }
                }

                if (index !== null && tlist[index].rating_2 == -99) {
                    tlist[index].rating_2 = rating;
                    tlist[index].seen_status = 2;

                    const Firstsessionobj = _.extend({}, fslist);
                    const trainingobj = _.extend({}, tlist);
                    const Secondsessionobj = _.extend({}, sslist);

                    const upimglist = JSON.stringify({
                        TRAINING_IMAGE_LIST: trainingobj,
                        FIRST_SESSION_IMAGE_LIST: Firstsessionobj,
                        SECOND_SESSION_IMAGE_LIST: Secondsessionobj,
                    });

                    await db.none('UPDATE users SET IMAGE_LIST = $1 WHERE email = $2', [upimglist, email]);
                }

                if (unseen_tl_list.length > 1) {
                    const file = unseen_tl_list[1];
                    const trainingcomobj = {
                        0: {
                            image_name: "00023_00_0.04s.png",
                            trainingcomment:
                                "This looks picture perfect, with perceptually no significant distortions! How much would you rate it?",
                        },
                        1: {
                            image_name: "10161_00_10s_SID_GT_autobrightoff.png",
                            trainingcomment:
                                "The top right and bottom right portions of the image seem a bit blurred , don't they? Move the slider and click Next to tell us how much you would rate it!",
                        },
                        2: {
                            image_name: "FUJI_10161_00_0.1s.png",
                            trainingcomment: "Looks Blurred , isn't it so?",
                        },
                        3: {
                            image_name: "FUJI_10161_00_0.1s_DIDN_he.png",
                            trainingcomment:
                                "This looks sharper as compared to the previous one , but colours seem to off! What do you think?",
                        },
                        4: {
                            image_name: "FUJI_10174_00_0.1s.png",
                            trainingcomment:
                                "Okay ,here we can actually witness what heavy noise can do to your image! It has even ruined the Color quality of the image ",
                        },
                        5: {
                            image_name: "FUJI_10174_00_0.1s_DIDN_ldr.png",
                            trainingcomment:
                                "Though it's a color image, contrast saturation is making it look as though it is grayscale!",
                        },
                        6: {
                            image_name: "SONY_00002_00_0.1s_matlabHEon3.png",
                            trainingcomment: "This is what over enhancement looks like!",
                        },
                        7: {
                            image_name: "SONY_10087_00_0.1s_DIDN_ldr.png",
                            trainingcomment:
                                "Can't see much? Well this is an example of under enhancement!",
                        },
                    };

                    let tempcom = "";

                    for (const i in _.range(Object.entries(trainingcomobj).length)) {
                        if (trainingcomobj[i].image_name.includes(String(file))) {
                            tempcom += trainingcomobj[i].trainingcomment;
                        }
                    }

                    const send = "\\" + file + "comment:" + tempcom;
                    const encrypted = CryptoJS.AES.encrypt(send, "doesntmatterifyouknowit");

                    res.redirect("/trainingphase2?message=" + encodeURIComponent(encrypted));
                } else {
                    res.redirect("/secondsession");
                }
            } else {
                console.log('User not found');
            }
        } catch (error) {
            console.log(error);
        }
    } else {
        res.render("login", {
            message: "Please login to Access this page!",
        });
    }
};

exports.nextfsimg = async (req, res) => {
    if (req.isAuthenticated) {
        const email = req.session.passport.user;
        console.log(req.body);
        const image_name = req.body.image_name;
        if (image_name.includes("\\")) {
            image_name = image_name.split("\\")[1];
        }

        const rating = req.body.rating;
        console.log(image_name);
        console.log(rating);
        try {
            const user = await db.oneOrNone('SELECT * FROM users WHERE email = $1', [email]);

            if (user) {
                const unseen_fs_list = [];
                const imglist = user.image_list;
                const fslist = imglist.FIRST_SESSION_IMAGE_LIST;
                const sslist = imglist.SECOND_SESSION_IMAGE_LIST;
                const tlist = imglist.TRAINING_IMAGE_LIST;

                let index = null;

                for (const i in _.range(Object.entries(fslist).length)) {
                    if (fslist[i].image_name == image_name) {
                        index = i;
                    }

                    if (fslist[i].seen_status == 0) {
                        unseen_fs_list.push(fslist[i].image_name);
                    }
                }

                if (index !== null && fslist[index].seen_status == 0) {
                    fslist[index].rating = rating;
                    fslist[index].seen_status = 1;

                    const Firstsessionobj = _.extend({}, fslist);
                    const trainingobj = _.extend({}, tlist);
                    const Secondsessionobj = _.extend({}, sslist);

                    const upimglist = JSON.stringify({
                        TRAINING_IMAGE_LIST: trainingobj,
                        FIRST_SESSION_IMAGE_LIST: Firstsessionobj,
                        SECOND_SESSION_IMAGE_LIST: Secondsessionobj,
                    });

                    await db.none('UPDATE users SET IMAGE_LIST = $1 WHERE email = $2', [upimglist, email]);
                }

                if (unseen_fs_list.length > 1) {
                    const file = "\\" + unseen_fs_list[1];
                    const send =
                        file +
                        "unseen:" +
                        String(unseen_fs_list.length) +
                        "total:" +
                        String(Object.entries(fslist).length) +
                        "uname:" +
                        String(user.name);

                    const encrypted = CryptoJS.AES.encrypt(send, "doesntmatterifyouknowit");
                    res.redirect("/firstsession?message=" + encodeURIComponent(encrypted));
                } else {
                    await db.none('UPDATE users SET fscstamp = CURRENT_TIMESTAMP WHERE email = $1', [email]);

                    return res.render("studyinterface", {
                        message: "Thank you, you have successfully completed the first session of the study!",
                    });
                }
            } else {
                console.log('User not found');
            }
        } catch (error) {
            console.log(error);
        }
    } else {
        res.render("login", {
            message: "Please login to Access this page!",
        });
    }
};

exports.nextssimg = async (req, res) => {
    if (req.isAuthenticated) {
        const email = req.session.passport.user;
        // id = id[1];
        console.log(req.body);
        const image_name = req.body.image_name;
        if (image_name.includes("\\")) {
            image_name = image_name.split("\\")[1];
        }

        const rating = req.body.rating;
        // console.log(image_name);
        // console.log(rating);
        try {
            const user = await db.oneOrNone('SELECT * FROM users WHERE email = $1', [email]);

            if (user) {
                const unseen_ss_list = [];
                const imglist = JSON.parse(user.IMAGE_LIST);

                const fslist = imglist.FIRST_SESSION_IMAGE_LIST;
                const sslist = imglist.SECOND_SESSION_IMAGE_LIST;
                const tlist = imglist.TRAINING_IMAGE_LIST;

                let index = null;

                for (const i in _.range(Object.entries(sslist).length)) {
                    if (sslist[i].image_name == image_name) {
                        index = i;
                    }

                    if (sslist[i].seen_status == 0) {
                        unseen_ss_list.push(sslist[i].image_name);
                    }
                }

                if (index !== null && sslist[index].seen_status == 0) {
                    sslist[index].rating = rating;
                    sslist[index].seen_status = 1;

                    const Firstsessionobj = _.extend({}, fslist);
                    const trainingobj = _.extend({}, tlist);
                    const Secondsessionobj = _.extend({}, sslist);

                    const upimglist = JSON.stringify({
                        TRAINING_IMAGE_LIST: trainingobj,
                        FIRST_SESSION_IMAGE_LIST: Firstsessionobj,
                        SECOND_SESSION_IMAGE_LIST: Secondsessionobj,
                    });

                    await db.none('UPDATE users SET IMAGE_LIST = $1 WHERE email = $2', [upimglist, email]);
                }

                if (unseen_ss_list.length > 1) {
                    const file = "\\" + unseen_ss_list[1];
                    const send =
                        file +
                        "unseen:" +
                        String(unseen_ss_list.length) +
                        "total:" +
                        String(Object.entries(sslist).length) +
                        "uname:" +
                        String(user.name);

                    const encrypted = CryptoJS.AES.encrypt(send, "doesntmatterifyouknowit");
                    res.redirect("/secondsession?message=" + encodeURIComponent(encrypted));
                } else {
                    return res.render("studyinterface", {
                        message: "Thank you, you have successfully completed the Second session of the study!",
                    });
                }
            } else {
                console.log('User not found');
            }
        } catch (error) {
            console.log(error);
        }
    } else {
        res.render("login", {
            message: "Please login to Access this page!",
        });
    }
};
exports.gotoinst = async (req, res) => {
    if (req.isAuthenticated) {
        try {
            var email = req.session.passport.user;
            const adu = JSON.stringify(req.body);
            const results = await db.oneOrNone("SELECT * FROM users WHERE email=$1", [email]);
            console.log("gotoinst :: adu :: results:: ", adu, "\n", results);
            if (results) {
                if (results.ADD_SUBJECT_DETAILS != null) {
                    console.log("gotoinst:: studyinterface");
                    res.redirect("/studyinterface");
                } else {
                    console.log("gotoinst:: asd");
                    res.redirect("/asd");
                }
            } else {
                res.render("login", {
                    message: "Please login to Access this page!",
                });
            }
        } catch (error) {
            console.log(error);
        }
    }
};

//

exports.ssd2 = async (req, res) => {
    if (req.isAuthenticated) {
        try {
            const email = req.session.passport.user;
            const adu2 = req.body;

            const user = await db.oneOrNone('SELECT * FROM users WHERE email = $1', [email]);

            if (user) {
                console.log("ASD2");
                const adu = JSON.parse(user.ADD_SUBJECT_DETAILS);
                const ADU = Object.assign({}, adu, adu2);
                const updatedADU = JSON.stringify(ADU);

                await db.none('UPDATE users SET ADD_SUBJECT_DETAILS = $1 WHERE email = $2', [updatedADU, email]);
                res.redirect("/trainingphase2");
            } else {
                console.log('User not found');
            }
        } catch (error) {
            console.log(error);
        }

    } else {
        res.render("login", {
            message: "Please login to Access this page!",
        });
    }
};


exports.uploadImage = async (req, res) => {
    const { filename, rating, comment, imageDescription, type } = req.body;
    const file = req.file;
    const imageName = file.originalname;
    const filePath = req.file.path;
    const patchNumber = filename.match(/patch_(\d+)/)[1];
    const subPatch = filename.match(/sub_patch_(\d+)/)[1];
    const imageId = `IMGP${patchNumber}SP${subPatch}`;

    console.log(file, imageName, filePath, filename, rating, comment);
    try {
        const result = await db.query(
            'INSERT INTO images (filename, rating, comment, imageName, imageDescription, type, imageId) VALUES ($1, $2, $3, $4, $5, $6,$7) RETURNING id',
            [filename, rating, comment, imageName, imageDescription, type, imageId]
        );

        console.log("result", result);
        // res.send(`Image uploaded with ID: ${result[0].id} and Image Name : ${filename}`);
        res.redirect('/success?id=${result[0].id}&filename=${filename}');
    } catch (error) {
        console.error(error);
        res.status(500).send('Error uploading image');
    }
};


