db.query('UPDATE users SET confirm_status = 1 WHERE id = ?', [decodedid], async (error, results) => {
                    if (error) {
                        console.log(error);

                    } else {

                        res.render('login', {
                            message: 'Verification Successful , Please Login'
                        })
                    }
                })