const express = require('express');
const multer = require('multer');
const authController = require('../controllers/auth');
const router = express.Router();
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/');
    },
    filename: function (req, file, cb) {
        cb(null, file.originalname);
    }
});
const upload = multer({ storage: storage });

router.post('/register', authController.register);
router.post('/login', authController.login);
router.post('/consent', authController.consent);
router.post('/startss', authController.startss);
router.post('/ssd', authController.ssd);
router.post('/getfirstsessionlist', authController.getfirstsessionlist);
router.post('/getsecondsessionlist', authController.getsecondsessionlist);
router.post('/nexttl1img', authController.nexttl1img);
router.post('/nexttl2img', authController.nexttl2img);
router.post('/nextfsimg', authController.nextfsimg);
router.post('/nextssimg', authController.nextssimg);
router.post('/gotoinst', authController.gotoinst);
router.post('/ssd2', authController.ssd2);


router.post('/uploadImage', upload.single('file'), authController.uploadImage);


// router.post('/nextssimg', authController.nextssimg);







module.exports = router;


