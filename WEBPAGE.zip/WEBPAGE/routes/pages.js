const express = require("express");
const router = express.Router();
// const mysql = require("mysql");
const db = require("../db/db");
//requiring path and fs modules
const path = require("path");
const fs = require("fs");
var _ = require("lodash");
const { stringify } = require("querystring");
const { concat } = require("lodash");

router.get("/", (req, res) => {
    res.render("index", {
        message:
            "Welcome, you have successfully logged in , Please visit Profile page to know more",
    });
});

router.get("/register", (req, res) => {
    res.render("register");
});

router.get("/research", (req, res) => {
    res.render("research");
});

router.get("/login", (req, res) => {
    res.render("login");
});

router.get("/uploadImage", (req, res) => {
    res.render("uploadImage");
});

router.get("/success", (req, res) => {
    res.render("success");
});

router.get("/informedconsent", authenticationMiddleware(), async (req, res) => {
    try {
        const email = req.user.email;
        console.log("informedconsent:: email", email);
        const results = await db.oneOrNone("SELECT * FROM users WHERE email = $1", [email]);
        console.log("informedconsent:: email :: results", email, results);

        if (results) {
            if (results.consent_form != null && results.ADD_SUBJECT_DETAILS != null) {
                console.log("studyinterface");
                res.redirect("/studyinterface");
            } else {
                if (results.consent_form != null) {
                    console.log("discalproc");
                    res.redirect("/discalproc");
                } else {
                    console.log("informedconsent");
                    res.render("informedconsent");
                }
            }
        }
    } catch (error) {
        console.error(error);
    }
});

router.get("/profile", authenticationMiddleware(), async (req, res) => {
    // console.log(req.isAuthenticated());
    try {
        const email = req.user.email;
        const results = await db.query('SELECT * FROM users WHERE email = $1', [email]);
        console.log("profile::Results", results);
        if (results) {
            const name = results.name;
            //   const imglist = JSON.parse(results[0].IMAGE_LIST);
            //   const fslist = imglist.FIRST_SESSION_IMAGE_LIST;
            //   const sslist = imglist.SECOND_SESSION_IMAGE_LIST;
            //   const unseen_img_fs_list = fslist.filter(img => img.seen_status === 0).map(img => img.image_name);
            //   const unseen_img_ss_list = sslist.filter(img => img.seen_status === 0).map(img => img.image_name);

            //   const fsprog = Math.round((1 - (unseen_img_fs_list.length / fslist.length)) * 100);
            //   const ssprog = Math.round((1 - (unseen_img_ss_list.length / sslist.length)) * 100);

            const message = `Hi ${name},` + "Welcome to your profile. Please ensure that you have a Laptop , Sufficient time and a stable internet connection before attempting the study! fsprog: ${fsprog} ssprog: ${ssprog}";

            res.render('profile', { message });
        } else {
            console.log('User not found');
            // Handle the case where the user is not found
        }
    } catch (error) {
        console.error(error);
        // Handle the error here
    }
});

router.get("/instructions", authenticationMiddleware(), (req, res) => {
    res.render("instructions");
});
router.get("/subjectinfo", authenticationMiddleware(), (req, res) => {
    res.render("subjectinfo");
});
router.get("/discalproc", authenticationMiddleware(), (req, res) => {
    res.render("discalproc");
});
router.get("/asd", authenticationMiddleware(), async (req, res) => {

    try {
        const email = req.user.email;
        const results = await db.query('SELECT * FROM users WHERE email = $1', [email]);

        if (results.consent_form !== null) {
            if (results.ADD_SUBJECT_DETAILS !== null) {
                console.log("asd::studyinterface");
                res.redirect('/studyinterface');
            } else {
                console.log("asd::asd");

                res.render('asd');
            }
        } else {
            console.log("asd::subjectinfo");

            res.redirect('/subjectinfo');
        }
    } catch (error) {
        console.error(error);
        // Handle the error here
    }

});

router.get("/asd2", authenticationMiddleware(), async (req, res) => {
    try {
        const email = req.user.email;
        const results = await db.oneOrNone("SELECT * FROM users WHERE email = $1", [email]);
        console.log("asd2:results", results);
        if (results) {
            const adu = results.ADD_SUBJECT_DETAILS
            if (!adu?.hasOwnProperty("brightness_session2")) {
                res.redirect("/trainingphase2");
            } else {
                res.render("asd2");
            }
        } else {
            console.log('User not found');
        }
    } catch (error) {
        console.log(error);
    }
});

router.get("/trainingphase1", authenticationMiddleware(), async (req, res) => {
    try {
        const email = req.session.passport.user;

        const user = await db.oneOrNone('SELECT * FROM users WHERE email = $1', [email]);

        if (user) {
            console.log("ASD2");
            const imglist = JSON.parse(user.IMAGE_LIST);
            const trainlist = imglist.TRAINING_IMAGE_LIST;

            const unseen_img_list = trainlist.filter(item => item.rating === -99);

            if (unseen_img_list.length > 0) {
                const cimg = unseen_img_list[0].image_name;
                const trainingcomobj = {
                    0: {
                        image_name: "00023_00_0.04s.png",
                        trainingcomment:
                            "This looks picture perfect, with perceptually no significant distortions! How much would you rate it?",
                    },
                    1: {
                        image_name: "10161_00_10s_SID_GT_autobrightoff.png",
                        trainingcomment:
                            "The top right and bottom right portions of the image seem a bit blurred , don't they? Move the slider and click Next to tell us how much you would rate it!",
                    },
                    2: {
                        image_name: "FUJI_10161_00_0.1s.png",
                        trainingcomment: "Looks Blurred , isn't it so?",
                    },
                    3: {
                        image_name: "FUJI_10161_00_0.1s_DIDN_he.png",
                        trainingcomment:
                            "This looks sharper as compared to the previous one , but colours seem to off! What do you think?",
                    },
                    4: {
                        image_name: "FUJI_10174_00_0.1s.png",
                        trainingcomment:
                            "Okay ,here we can actually witness what heavy noise can do to your image! It has even ruined the Color quality of the image ",
                    },
                    5: {
                        image_name: "FUJI_10174_00_0.1s_DIDN_ldr.png",
                        trainingcomment:
                            "Though it's a color image, contrast saturation is making it look as though it is grayscale!",
                    },
                    6: {
                        image_name: "SONY_00002_00_0.1s_matlabHEon3.png",
                        trainingcomment: "This is what over enhancement looks like!",
                    },
                    7: {
                        image_name: "SONY_10087_00_0.1s_DIDN_ldr.png",
                        trainingcomment:
                            "Can't see much? Well this is an example of under enhancement!",
                    },
                };

                const tempcom = Object.values(trainingcomobj).find(item => item.image_name.includes(cimg)).trainingcomment;
                const send = `\\${cimg}comment:${tempcom}`;

                if (user.consent_form !== null && user.ADD_SUBJECT_DETAILS !== null) {
                    res.render("trainingphase1", { message: send });
                } else {
                    res.redirect("/subjectinfo");
                }
            } else {
                res.redirect("/firstsession");
            }
        } else {
            console.log('User not found');
        }
    } catch (error) {
        console.log(error);
    }
});

router.get("/firstsession", authenticationMiddleware(), async (req, res) => {
    try {
        const email = req.session.passport.user;
        const user = await db.oneOrNone('SELECT * FROM users WHERE email = $1', [email]);

        if (user) {
            const imglist = user.IMAGE_LIST;
            const trainlist = imglist?.TRAINING_IMAGE_LIST;

            const unseen_img_list = trainlist?.some(item => item.seen_status === 0);

            if (unseen_img_list) {
                return res.redirect("/trainingphase1");
            }

            const userFsList = await db.oneOrNone('SELECT * FROM users WHERE email = $1', [email]);

            if (userFsList) {
                const fslist = userFsList.IMAGE_LIST.FIRST_SESSION_IMAGE_LIST;
                const unseen_img_fs_list = fslist.some(item => item.seen_status === 0);

                if (unseen_img_fs_list) {
                    const cimg = fslist.find(item => item.seen_status === 0).image_name;
                    const message = `\\${cimg}unseen:${unseen_img_fs_list.length}total:${fslist.length}uname:${userFsList.name}`;
                    return res.render("firstsession", { message });
                }

                return res.render("studyinterface", { message: "Thank you, you have already completed the first session of the study!" });
            }

            console.log('User not found');
        } else {
            console.log('User not found');
        }
    } catch (error) {
        console.log(error);
    }

});

router.get("/trainingphase2", authenticationMiddleware(), async (req, res) => {
    try {
        const email = req.session.passport.user;

        const user = await db.oneOrNone('SELECT * FROM users WHERE email = $1', [email]);

        if (user) {
            const imglist = JSON.parse(user.IMAGE_LIST);
            const trainlist = imglist.TRAINING_IMAGE_LIST;
            const fslist = imglist.FIRST_SESSION_IMAGE_LIST;

            const unseen_img_list = trainlist.filter(item => item.rating_2 === -99);
            const unseen_fss_list = fslist.filter(item => item.seen_status === 0);

            if (unseen_img_list.length > 0) {
                if (unseen_fss_list.length > 0) {
                    res.render("studyinterface", {
                        message: "Second session can only be accessed after completing first session!",
                    });
                } else {
                    const cimg = unseen_img_list[0].image_name;
                    const trainingcomobj = {
                        0: {
                            image_name: "00023_00_0.04s.png",
                            trainingcomment:
                                "This looks picture perfect, with perceptually no significant distortions! How much would you rate it?",
                        },
                        1: {
                            image_name: "10161_00_10s_SID_GT_autobrightoff.png",
                            trainingcomment:
                                "The top right and bottom right portions of the image seem a bit blurred , don't they? Move the slider and click Next to tell us how much you would rate it!",
                        },
                        2: {
                            image_name: "FUJI_10161_00_0.1s.png",
                            trainingcomment: "Looks Blurred , isn't it so?",
                        },
                        3: {
                            image_name: "FUJI_10161_00_0.1s_DIDN_he.png",
                            trainingcomment:
                                "This looks sharper as compared to the previous one , but colours seem to off! What do you think?",
                        },
                        4: {
                            image_name: "FUJI_10174_00_0.1s.png",
                            trainingcomment:
                                "Okay ,here we can actually witness what heavy noise can do to your image! It has even ruined the Color quality of the image ",
                        },
                        5: {
                            image_name: "FUJI_10174_00_0.1s_DIDN_ldr.png",
                            trainingcomment:
                                "Though it's a color image, contrast saturation is making it look as though it is grayscale!",
                        },
                        6: {
                            image_name: "SONY_00002_00_0.1s_matlabHEon3.png",
                            trainingcomment: "This is what over enhancement looks like!",
                        },
                        7: {
                            image_name: "SONY_10087_00_0.1s_DIDN_ldr.png",
                            trainingcomment:
                                "Can't see much? Well this is an example of under enhancement!",
                        },
                    };

                    let tempcom = "";
                    for (let i = 0; i < Object.entries(trainingcomobj).length; i++) {
                        if (trainingcomobj[i].image_name.includes(String(cimg))) {
                            tempcom += trainingcomobj[i].trainingcomment;
                        }
                    }
                    const send = `\\${cimg}comment:${tempcom}`;

                    res.render("trainingphase2", { message: send });
                }
            } else {
                res.redirect("/secondsession");
            }
        } else {
            console.log('User not found');
        }
    } catch (error) {
        console.log(error);
    }
});

router.get("/secondsession", authenticationMiddleware(), async (req, res) => {
    try {
        const email = req.session.passport.user;
        const user = await db.oneOrNone('SELECT * FROM users WHERE email = $1', [email]);

        if (user) {
            const stamp = user.fscstamp;
            const currentDate = new Date();
            const currtimestamp = currentDate.getTime();

            function timeDiff(curr, prev) {
                const diff = curr - prev; // Difference between dates in milliseconds
                return Math.round(diff / 1000); // Convert to seconds
            }

            const elap = timeDiff(currtimestamp, stamp);

            if (elap <= 60 * 60 * 24) {
                const tl = 60 * 60 * 24 - elap;
                return res.render("studyinterface", {
                    message: `Please wait for 24 hours at least before attempting the next session of our Study! tl:${tl}`,
                });
            }

            const imglist = JSON.parse(user.IMAGE_LIST);
            const trainlist = imglist.TRAINING_IMAGE_LIST;
            const fslist = imglist.FIRST_SESSION_IMAGE_LIST;

            const unseen_img_list = trainlist.filter(item => item.rating_2 === -99);
            const unseen_fss_list = fslist.filter(item => item.seen_status === 0);

            if (unseen_img_list.length > 0) {
                if (unseen_fss_list.length > 0) {
                    return res.render("studyinterface", {
                        message: "Second session can only be accessed after completing the first session!",
                    });
                } else {
                    return res.redirect("/asd2");
                }
            } else {
                const user2 = await db.oneOrNone('SELECT * FROM users WHERE id = $1', [id]);
                if (user2) {
                    const imglist2 = JSON.parse(user2.IMAGE_LIST);
                    const sslist = imglist2.SECOND_SESSION_IMAGE_LIST;

                    const unseen_img_ss_list = sslist.filter(item => item.seen_status === 0);

                    if (unseen_img_ss_list.length > 0) {
                        const cimg = unseen_img_ss_list[0].image_name;
                        const message = `\\${cimg}unseen:${unseen_img_ss_list.length}total:${Object.entries(sslist).length}uname:${user2.name}`;
                        return res.render("secondsession", { message });
                    } else {
                        return res.render("studyinterface", {
                            message: "Thank you, you have successfully completed the second session of the study!",
                        });
                    }
                }
            }
        } else {
            console.log('User not found');
        }
    } catch (error) {
        console.log(error);
    }
});
router.get("/studyinterface", authenticationMiddleware(), async (req, res) => {
    try {
        const csf = JSON.stringify(req.body);
        const email = req.user.email;
        const userResults = await db.oneOrNone('SELECT * FROM users WHERE email = $1', [email]);
        console.log("studyinterface::userResults", userResults);
        if (userResults) {
            const email = userResults.email;
            await db.oneOrNone('UPDATE users SET consent_form = $1 WHERE email = $2', [csf, email]);
            console.log("studyinterface::discalproc");
            res.redirect('/discalproc');
        } else {
            console.log('User not found');
            // Handle the case where the user is not found
        }
    } catch (error) {
        console.error(error);
        // Handle the error here
    }

});
router.get("/logout", (req, res) => {
    const id = req.user[1];
    console.log("User " + String(id) + " Logging out");
    req.logout();
    req.session.destroy();
    res.redirect("/");
});

router.get("/adminportal", authenticationMiddleware(), (req, res) => {
    console.log(req.isAuthenticated());
    const email = req.user.email;
    console.log("req.user", req.user);
    db.one("SELECT * FROM users WHERE email = $1", [email])
        .then((user) => {
            const name = user.name;
            if (email === "sarvesh@iisc.ac.in") {
                res.render("adminportal", {
                    message: `Hi ADMIN, ${name} Welcome to your profile. Please ensure that you have a laptop, sufficient time and a stable internet connection before attempting the study!`,
                });
            } else {
                res.redirect("/profile");
            }
        })
        .catch((error) => {
            console.log(error);
            // Handle the error here
        });
});

router.get('/getImages', async (req, res) => {
    try {
        const result = await db.query(`SELECT * FROM images where type ='RGB'`);
        // console.log("results",result);
        res.render('getImages', { images: result });
    } catch (error) {
        console.error(error);
        res.status(500).send('Error retrieving images');
    }
});

router.get('/showImage/:imageid', async (req, res) => {
    try {
        const imageId = req.params.imageid;
        console.log("imageId", typeof imageId, imageId);
        const result = await db.query(`SELECT * FROM images WHERE imageid = $1`, [imageId]);
        console.log("result::", result);
        res.render('showImage', { images: result });


    } catch (error) {
        res.status(400).send('The imageId parameter must be an integer.');

    }
});


// router.get('/showImages', async (req, res) => {
//   try {
//     const result = await db.query(`SELECT * FROM images where type ='RGB'`);
//     console.log("results",result);
//     res.render('showImage', { images: result });
//   } catch (error) {
//     console.error(error);
//     res.status(500).send('Error retrieving images');
//   }
//   // Render the /showImages page with the object as the data.
// });



function authenticationMiddleware() {
    return (req, res, next) => {
        console.log(
            `req.session.passport.user: ${JSON.stringify(req.session.passport)}`
        );

        if (req.isAuthenticated()) return next();
        res.render("login", {
            message: "Please login to Access this page!",
        });
    };
}

module.exports = router;


