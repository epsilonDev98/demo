const express = require("express");
// const mysql = require("mysql");
const db = require('./db/db');
const app = express();
const path = require('path');
const cookieParser = require('cookie-parser');
const multer = require('multer');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
// Authentication Packages
var session = require('express-session');
var pgSession = require('express-pg-session')(session);

const publicDirectory = path.join(__dirname, './public')
/***front end files location */
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/');
    },
    filename: function (req, file, cb) {
        cb(null, file.originalname);
    }
});

const upload = multer({ storage: storage });
app.use(express.static(publicDirectory));
//Parse URL encoded bodies (as sent by HtML forms)
app.use(express.urlencoded({ extended: false }));
//Parse JSON bodies as sent by API clients
app.use(express.json());
app.use(cookieParser());


const pgSessionStore = new pgSession({
    pgPromise: db,
    tableName: 'session'
});
app.use(session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    store: pgSessionStore,
    saveUninitialized: true,
    //cookie: { secure: true }
}));
app.use(passport.initialize());
app.use(passport.session());
// Define a LocalStrategy for authenticating users
passport.use(new LocalStrategy(
    async (username, password, done) => {
        try {
            const result = await pool.query('SELECT * FROM users WHERE username = $1', [username]);
            const user = result.rows[0];

            if (!user) {
                return done(null, false, { message: 'Incorrect username.' });
            }

            // if (!bcrypt.compareSync(password, user.password)) {
            //   return done(null, false, { message: 'Incorrect password.' });
            // }

            return done(null, user);
        } catch (error) {
            return done(error);
        }
    }
));
// Serialize and deserialize user information for sessions
passport.serializeUser((user, done) => {
    done(null, user.email);
});

passport.deserializeUser(async (email, done) => {
    try {
        console.log(`Deserializing user with id: ${email}`, JSON.stringify(email));
        const result = await db.query('SELECT * FROM users WHERE email = $1', [email]);

        if (result.length === 0) {
            console.log("User not found");
            return done(null, false);
        }

        const user = result[0];
        console.log("Found user:", user);
        done(null, user);
    } catch (error) {
        console.error(error);
        done(error);
    }
});




app.use(function (req, res, next) {
    res.locals.isAuthenticated = req.isAuthenticated();
    next();
});


app.set('view engine', 'hbs');   /**html template engine */

//Define Routes
app.use('/', require('./routes/pages'));
app.use('/auth', require('./routes/auth'));
app.use('/uploads', express.static('uploads'));
app.use(express.static('./views/images'));
app.use(express.static('./dataset'));
const port = 5001


app.listen(port, () => {
    console.log("Server started at 5001")
})




