const express = require('express');
var passport = require('passport');
const router = express.Router();
const mysql = require("mysql");

const db = mysql.createConnection({
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE

});


const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');



//requiring path and fs modules
const dotenv = require('dotenv');                                /****imp env variables */
dotenv.config({ path: './.env' });
const path = require('path');
const fs = require('fs');
var _ = require('lodash');
const { stringify } = require('querystring');
const { concat } = require('lodash');


router.get('/', (req, res) => {

    res.render('index', {
        message: 'Welcome, you have successfully logged in , Please visit Profile page to know more'

    });


})

router.get('/register', (req, res) => {
    res.render('register');
})

router.get('/research', (req, res) => {
    res.render('research');
})

router.get('/login', (req, res) => {
    res.render('login');
})


router.get('/informedconsent', authenticationMiddleware(), (req, res) => {



    // console.log(req.isAuthenticated());
    const id = req.user[1]
    db.query('SELECT * FROM users WHERE id = ?', [id], (error, results) => {
        if (error) {
            console.log(error);
        }
        else {
            if (results[0].consent_form != null && results[0].ADD_SUBJECT_DETAILS != null) {
                res.redirect('/studyinterface');

            }
            else {
                if (results[0].consent_form != null) {
                    res.redirect('/discalproc')
                }
                else {
                    res.render('informedconsent')
                }

            }
        }
    })


})

router.get('/profile', authenticationMiddleware(), (req, res) => {

    // console.log(req.isAuthenticated());
    const id = req.user[1]
    db.query('SELECT * FROM users WHERE id = ?', [id], (error, results) => {
        if (error) {
            console.log(error);
        }
        else {
            const name = results[0].name;
            var imglist = JSON.parse(results[0].IMAGE_LIST);
            fslist = imglist.FIRST_SESSION_IMAGE_LIST;
            sslist = imglist.SECOND_SESSION_IMAGE_LIST;
            var unseen_img_fs_list = [];
            for (var i in _.range(Object.entries(fslist).length)) {


                if (fslist[i].seen_status == 0) {

                    unseen_img_fs_list.push(fslist[i].image_name);

                }
            }

            var unseen_img_ss_list = [];
            for (var i in _.range(Object.entries(sslist).length)) {


                if (sslist[i].seen_status == 0) {

                    unseen_img_ss_list.push(sslist[i].image_name);

                }
            }
            var fsprog = Math.round(((Object.entries(fslist).length - unseen_img_fs_list.length) / Object.entries(fslist).length) * 100)
            var ssprog = Math.round(((Object.entries(sslist).length - unseen_img_ss_list.length) / Object.entries(sslist).length) * 100)
            var file = 'Hi ' + name + ', Welcome to your profile. Please ensure that you have a Laptop , Sufficient time and a stable internet connection before attempting the study!' + "fsprog:" + String(fsprog) + "ssprog:" + String(ssprog)

            res.render('profile', {

                message: file

            });
        }
    })



})

router.get('/instructions', authenticationMiddleware(), (req, res) => {
    res.render('instructions');
})
router.get('/subjectinfo', authenticationMiddleware(), (req, res) => {
    res.render('subjectinfo');
});
router.get('/discalproc', authenticationMiddleware(), (req, res) => {
    res.render('discalproc');
});
router.get('/asd', authenticationMiddleware(), (req, res) => {
    const id = req.user[1]
    db.query('SELECT * FROM users WHERE id = ?', [id], (error, results) => {
        if (error) {
            console.log(error);
        }
        else {

            if (results[0].consent_form != null) {
                if (results[0].ADD_SUBJECT_DETAILS != null) {
                    res.redirect('/studyinterface');

                }
                else {
                    res.render('asd')
                }
            }
            else {
                res.redirect('/subjectinfo')
            }
        }
    })
});


router.get('/asd2', authenticationMiddleware(), (req, res) => {


    const id = req.user[1]
    db.query('SELECT * FROM users WHERE id = ?', [id], (error, results) => {
        if (error) {
            console.log(error);
        }
        else {

            adu = JSON.parse(results[0].ADD_SUBJECT_DETAILS);
            if (adu.hasOwnProperty('brightness_session2')) {
                res.redirect('/trainingphase2')
            }
            else {
                res.render('asd2')
            }
        }
    })



})

router.get('/trainingphase1', authenticationMiddleware(), (req, res) => {
    var id = req.session.passport.user;
    id = id[1];

    db.query('SELECT * FROM users WHERE id=?', [id], async (error, results) => {
        if (error) {
            console.log(error);
        }
        else {
            var imglist = JSON.parse(results[0].IMAGE_LIST);
            trainlist = imglist.TRAINING_IMAGE_LIST;

            var unseen_img_list = [];
            for (var i in _.range(Object.entries(trainlist).length)) {


                if (trainlist[i].rating == -99) {

                    unseen_img_list.push(trainlist[i].image_name);

                }
            }
            if (unseen_img_list.length > 0) {
                cimg = unseen_img_list[0];
                trainingcomobj = {
                    "0": { "image_name": "00023_00_0.04s.png", "trainingcomment": "This looks picture perfect, with perceptually no significant distortions! How much would you rate it?" },
                    "1": { "image_name": "10161_00_10s_SID_GT_autobrightoff.png", "trainingcomment": "The top right and bottom right portions of the image seem a bit blurred , don't they? Move the slider and click Next to tell us how much you would rate it!" },
                    "2": { "image_name": "FUJI_10161_00_0.1s.png", "trainingcomment": "Looks Blurred , isn't it so?" },
                    "3": { "image_name": "FUJI_10161_00_0.1s_DIDN_he.png", "trainingcomment": "This looks sharper as compared to the previous one , but colours seem to off! What do you think?" },
                    "4": { "image_name": "FUJI_10174_00_0.1s.png", "trainingcomment": "Okay ,here we can actually witness what heavy noise can do to your image! It has even ruined the Color quality of the image " },
                    "5": { "image_name": "FUJI_10174_00_0.1s_DIDN_ldr.png", "trainingcomment": "Though it's a color image, contrast saturation is making it look as though it is grayscale!" },
                    "6": { "image_name": "SONY_00002_00_0.1s_matlabHEon3.png", "trainingcomment": "This is what over enhancement looks like!" },
                    "7": { "image_name": "SONY_10087_00_0.1s_DIDN_ldr.png", "trainingcomment": "Can't see much? Well this is an example of under enhancement!" }
                }

                tempcom = "";
                for (var i in _.range(Object.entries(trainingcomobj).length)) {


                    if (trainingcomobj[i].image_name.includes(String(cimg))) {

                        tempcom = tempcom + trainingcomobj[i].trainingcomment;

                    }

                }
                send = "\\" + cimg + "comment:" + tempcom;
                if (results[0].consent_form != null && results[0].ADD_SUBJECT_DETAILS != null) {
                    res.render('trainingphase1', {
                        message: send
                    });
                }
                else {

                    res.redirect('/subjectinfo');
                }



            }
            else {
                res.redirect('/firstsession')
            }
        }
    });
});

router.get('/firstsession', authenticationMiddleware(), (req, res) => {
    var id = req.session.passport.user;
    id = id[1];

    db.query('SELECT * FROM users WHERE id=?', [id], async (error, results) => {
        if (error) {
            console.log(error);
        }
        else {
            var imglist = JSON.parse(results[0].IMAGE_LIST);
            trainlist = imglist.TRAINING_IMAGE_LIST;

            var unseen_img_list = [];
            for (var i in _.range(Object.entries(trainlist).length)) {


                if (trainlist[i].seen_status == 0) {

                    unseen_img_list.push(trainlist[i].image_name);

                }
            }
            if (unseen_img_list.length > 0) {
                res.redirect('/trainingphase1')

            }
            else {
                var id = req.session.passport.user;
                id = id[1];

                db.query('SELECT * FROM users WHERE id=?', [id], async (error, results) => {
                    if (error) {
                        console.log(error);
                    }
                    else {
                        var imglist = JSON.parse(results[0].IMAGE_LIST);
                        fslist = imglist.FIRST_SESSION_IMAGE_LIST;

                        var unseen_img_fs_list = [];
                        for (var i in _.range(Object.entries(fslist).length)) {


                            if (fslist[i].seen_status == 0) {

                                unseen_img_fs_list.push(fslist[i].image_name);

                            }
                        }
                        if (unseen_img_fs_list.length > 0) {
                            cimg = unseen_img_fs_list[0];
                            send = "\\" + cimg + "unseen:" + String(unseen_img_fs_list.length) + "total:" + String(Object.entries(fslist).length) + "uname:" + String(results[0].name);


                            res.render('firstsession', {
                                message: send
                            });

                        }
                        else {


                            return res.render('studyinterface', {
                                message: "Thank you , you have Already completed the first session of the study!"
                            });
                        }
                    }
                });
            }
        }
    });
});



router.get('/trainingphase2', authenticationMiddleware(), (req, res) => {
    var id = req.session.passport.user;
    id = id[1];

    db.query('SELECT * FROM users WHERE id=?', [id], async (error, results) => {
        if (error) {
            console.log(error);
        }
        else {
            var imglist = JSON.parse(results[0].IMAGE_LIST);
            trainlist = imglist.TRAINING_IMAGE_LIST;
            fslist = imglist.FIRST_SESSION_IMAGE_LIST;

            var unseen_img_list = [];
            for (var i in _.range(Object.entries(trainlist).length)) {


                if (trainlist[i].rating_2 == -99) {

                    unseen_img_list.push(trainlist[i].image_name);

                }

            }
            var unseen_fss_list = [];
            for (var i in _.range(Object.entries(fslist).length)) {


                if (fslist[i].seen_status == 0) {

                    unseen_fss_list.push(fslist[i].image_name);

                }
            }

            if (unseen_img_list.length > 0) {

                if (unseen_fss_list.length > 0) {
                    res.render('studyinterface', {
                        message: "Second session can only be accessed after completing first session!"
                    })
                }
                else {


                    cimg = unseen_img_list[0];
                    trainingcomobj = {
                        "0": { "image_name": "00023_00_0.04s.png", "trainingcomment": "This looks picture perfect, with perceptually no significant distortions! How much would you rate it?" },
                        "1": { "image_name": "10161_00_10s_SID_GT_autobrightoff.png", "trainingcomment": "The top right and bottom right portions of the image seem a bit blurred , don't they? Move the slider and click Next to tell us how much you would rate it!" },
                        "2": { "image_name": "FUJI_10161_00_0.1s.png", "trainingcomment": "Looks Blurred , isn't it so?" },
                        "3": { "image_name": "FUJI_10161_00_0.1s_DIDN_he.png", "trainingcomment": "This looks sharper as compared to the previous one , but colours seem to off! What do you think?" },
                        "4": { "image_name": "FUJI_10174_00_0.1s.png", "trainingcomment": "Okay ,here we can actually witness what heavy noise can do to your image! It has even ruined the Color quality of the image " },
                        "5": { "image_name": "FUJI_10174_00_0.1s_DIDN_ldr.png", "trainingcomment": "Though it's a color image, contrast saturation is making it look as though it is grayscale!" },
                        "6": { "image_name": "SONY_00002_00_0.1s_matlabHEon3.png", "trainingcomment": "This is what over enhancement looks like!" },
                        "7": { "image_name": "SONY_10087_00_0.1s_DIDN_ldr.png", "trainingcomment": "Can't see much? Well this is an example of under enhancement!" }
                    }

                    tempcom = "";
                    for (var i in _.range(Object.entries(trainingcomobj).length)) {


                        if (trainingcomobj[i].image_name.includes(String(cimg))) {

                            tempcom = tempcom + trainingcomobj[i].trainingcomment;

                        }

                    }
                    send = "\\" + cimg + "comment:" + tempcom;
                    res.render('trainingphase2', {
                        message: send
                    });

                }

            }
            else {
                res.redirect('/secondsession')
            }
        }
    });
});

router.get('/secondsession', authenticationMiddleware(), (req, res) => {
    var id = req.session.passport.user;
    id = id[1];



    db.query('SELECT * FROM users WHERE id=?', [id], async (error, results) => {
        if (error) {
            console.log(error);
        }
        else {
            var stamp = results[0].fscstamp;
            var currentDate = new Date();
            var currtimestamp = currentDate.getTime();
            function timeDiff(curr, prev) {
                var ms_Min = 60 * 1000; // milliseconds in Minute 
                var ms_Hour = ms_Min * 60; // milliseconds in Hour 
                var ms_Day = ms_Hour * 24; // milliseconds in day 
                var ms_Mon = ms_Day * 30; // milliseconds in Month 
                var ms_Yr = ms_Day * 365; // milliseconds in Year 
                var diff = curr - prev; //difference between dates. 
                // If the diff is less then milliseconds in a minute 

                return Math.round(diff / 1000)


            }
            elap = timeDiff(currtimestamp, stamp);
            // if (elap <= 60 * 60 * 24) {
            //     tl = 60 * 60 * 24 - elap;

            //     return res.render('studyinterface', {
            //         message: "Please wait for 24 hours atleast before attempting the next session of our Study!" + "tl:" + String(tl)
            //     });
            // }

            if (elap <= 60 * 60 * 24) {

                tl = 60 * 60 * 24 - elap;
                // console.log(tl);

                return res.render('studyinterface', {
                    message: "Please wait for 24 hours atleast before attempting the next session of our Study!" + "tl:" + String(tl)
                });
            }
            var imglist = JSON.parse(results[0].IMAGE_LIST);
            trainlist = imglist.TRAINING_IMAGE_LIST;
            fslist = imglist.FIRST_SESSION_IMAGE_LIST;


            var unseen_img_list = [];
            for (var i in _.range(Object.entries(trainlist).length)) {


                if (trainlist[i].rating_2 == -99) {

                    unseen_img_list.push(trainlist[i].image_name);

                }
            }
            var unseen_fss_list = [];
            for (var i in _.range(Object.entries(fslist).length)) {


                if (fslist[i].seen_status == 0) {

                    unseen_fss_list.push(fslist[i].image_name);

                }
            }
            if (unseen_img_list.length > 0) {

                if (unseen_fss_list.length > 0) {
                    res.render('studyinterface', {
                        message: "Second session can only be accessed after completing first session!"
                    })
                }
                else {

                    res.redirect('/asd2')
                }

            }
            else {
                var id = req.session.passport.user;
                id = id[1];

                db.query('SELECT * FROM users WHERE id=?', [id], async (error, results) => {
                    if (error) {
                        console.log(error);
                    }
                    else {
                        var imglist = JSON.parse(results[0].IMAGE_LIST);
                        sslist = imglist.SECOND_SESSION_IMAGE_LIST;

                        var unseen_img_ss_list = [];
                        for (var i in _.range(Object.entries(sslist).length)) {


                            if (sslist[i].seen_status == 0) {

                                unseen_img_ss_list.push(sslist[i].image_name);

                            }
                        }
                        if (unseen_img_ss_list.length > 0) {
                            cimg = unseen_img_ss_list[0];
                            send = "\\" + cimg + "unseen:" + String(unseen_img_ss_list.length) + "total:" + String(Object.entries(sslist).length) + "uname:" + String(results[0].name);
                            res.render('secondsession', {
                                message: send
                            });

                        }
                        else {
                            res.render('studyinterface', {
                                message: "Thank you , you have successfully completed the Second session of the study!"
                            });
                        }
                    }
                });
            }
        }
    });
    // }
});
router.get('/studyinterface', authenticationMiddleware(), (req, res) => {

    const id = req.user[1]
    db.query('SELECT * FROM users WHERE id = ?', [id], (error, results) => {
        if (error) {
            console.log(error);
        }
        else {
            if (results[0].consent_form != null && results[0].ADD_SUBJECT_DETAILS != null) {
                res.render('studyinterface');

            }
            else {
                if (results[0].consent_form == null) {
                    res.redirect('/subjectinfo');
                }
                else if (results[0].ADD_SUBJECT_DETAILS == null) {
                    res.redirect('/asd')
                }
            }
        }
    })

})
router.get('/logout', (req, res) => {
    const id = req.user[1];
    console.log("User " + String(id) + " Logging out")
    req.logout();
    req.session.destroy();
    res.redirect('/');


})


router.get('/adminportal', authenticationMiddleware(), (req, res) => {

    // console.log(req.isAuthenticated());
    const id = req.user[1]
    db.query('SELECT * FROM users WHERE id = ?', [id], (error, results) => {
        if (error) {
            console.log(error);
        }
        else {
            const name = results[0].name;
            if (id == 118) {
                res.render('adminportal', {
                    message: 'Hi ADMIN,  ' + name + '  Welcome to your profile. Please ensure that you have a laptop , sufficient time and a stable internet connection before attempting the study!'

                });
            }
            else {
                res.redirect('/profile')
            }
        }
    })



})

function authenticationMiddleware() {
    return (req, res, next) => {
        console.log(`req.session.passport.user: ${JSON.stringify(req.session.passport)}`);

        if (req.isAuthenticated()) return next();
        res.render('login', {
            message: 'Please login to Access this page!'
        });
    }
}



module.exports = router;