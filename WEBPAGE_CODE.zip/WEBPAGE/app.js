const express = require("express");
const mysql = require("mysql");
const app = express();
const dotenv = require('dotenv');                                /****imp env variables */
const path = require('path');
const cookieParser = require('cookie-parser');
dotenv.config({ path: './.env' });

// Authentication Packages
var session = require('express-session');
var passport = require('passport');
var MySQLStore = require('express-mysql-session')(session);


const db = mysql.createConnection({
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE

});

const publicDirectory = path.join(__dirname, './public')
/***front end files location */
app.use(express.static(publicDirectory));
//Parse URL encoded bodies (as sent by HtML forms)
app.use(express.urlencoded({ extended: false }));
//Parse JSON bodies as sent by API clients
app.use(express.json());
app.use(cookieParser());

var options = {
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE
};

var sessionStore = new MySQLStore(options);

app.use(session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    store: sessionStore,
    saveUninitialized: false,
    //cookie: { secure: true }
}));
app.use(passport.initialize());
app.use(passport.session());
app.use(function (req, res, next) {
    res.locals.isAuthenticated = req.isAuthenticated();
    next();
});


app.set('view engine', 'hbs');   /**html template engine */

db.connect((error) => {
    if (error) {
        console.log(error)
    } else {
        console.log("MYSQL Connected...")

    }

})


//Define Routes
app.use('/', require('./routes/pages'));
app.use('/auth', require('./routes/auth'));

app.use(express.static('./views/images'));
app.use(express.static('./dataset'));
const port = 5000


app.listen(port, () => {
    console.log("Server started at 5000")
})




