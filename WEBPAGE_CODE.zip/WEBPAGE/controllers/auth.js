const mysql = require("mysql");
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const emailexist = require("email-existence");
const nodemailer = require("nodemailer");
var passport = require('passport');
var CryptoJS = require("crypto-js");




//requiring path and fs modules
const dotenv = require('dotenv');                                /****imp env variables */
dotenv.config({ path: './.env' });
const path = require('path');
const fs = require('fs');
var _ = require('lodash');
const { stringify } = require('querystring');
const { concat } = require('lodash');

//joining path of directory 



const db = mysql.createConnection({
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE

});

/*****Login function called as a method of authController */
exports.login = async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).render('login', {
                message: 'Please provide Email and Password'
            })
        }


        db.query('SELECT * FROM users WHERE email = ?', [email], async (error, results) => {


            if (!results[0]) {
                res.status(400).render('login', {
                    message: 'Please Register Before trying to Log In!'

                });

            }
            else {
                if (!results || !(await bcrypt.compare(password, results[0].password))) {

                    res.status(401).render('login', {

                        message: 'Invalid Email/Password'
                    })
                } else {



                    const user_id = Object.entries(results[0])[0];
                    const email = Object.entries(results[0])[2]

                    console.log(user_id);
                    if (email[1] == "vigneshkanna@iisc.ac.in") {

                        req.login(user_id, function (err) {
                            res.redirect('/adminportal')
                        })

                    }
                    else {

                        req.login(user_id, function (err) {
                            res.redirect('/')
                        })
                    }



                }
            }


        });
    }
    catch (error) {
        console.log(error);
    }

}











/*****Register function called as a method of authController */
exports.register = (req, res) => {
    console.log(req.body);


    const { name, email, password, passwordConfirm } = req.body;


    db.query('SELECT email FROM users WHERE email= ?', [email], async (error, results) => {
        if (error) {
            console.log(error);
        }
        if (results.length > 0) {
            return res.render('register', {
                message: 'That email has been already registered'
            })
        } else if (password !== passwordConfirm) {
            return res.render('register', {
                message: 'Passwords do not match'
            });
        }

        let hashedPassword = await bcrypt.hash(password, 8);
        console.log(hashedPassword);

        db.query('SELECT * FROM users WHERE email IS NULL', async (error, results) => {
            if (error) {
                console.log(error);

            } else {
                var userid = results[0].id
                db.query('UPDATE users SET `name` = ?, `email` = ?, `password` = ? WHERE id=?', [name, email, hashedPassword, userid], async (error, results) => {
                    if (error) {
                        console.log(error);

                    } else {

                        return res.render('register', {
                            message: 'Registration Successful'
                        });
                    }
                })


            }
        });


    });




}


passport.serializeUser(function (user_id, done) {
    done(null, user_id);
});

passport.deserializeUser(function (user_id, done) {
    done(null, user_id);
});



exports.startss = (req, res) => {
    if (req.isAuthenticated) {
        var id = req.session.passport.user;
        id = id[1];

        db.query('SELECT * FROM users WHERE id=?', [id], async (error, results) => {
            if (error) {
                console.log(error);
            }
            else {


                if (results[0].consent_form == null) {
                    res.redirect('/subjectinfo')
                }

                else {
                    res.redirect('/discalproc')
                }





            }
        });

    }
    else {
        res.render('login', {
            message: 'Please login to Access this page!'
        });
    }
}


exports.consent = (req, res) => {
    if (req.isAuthenticated) {
        var id = req.session.passport.user;
        id = id[1];
        const csf = JSON.stringify(req.body);
        db.query('SELECT * FROM users WHERE id=?', [id], async (error, results) => {
            if (error) {
                console.log(error);
            }
            else {
                // if (results[0].ADD_SUBJECT_DETAILS == null) {
                //     db.query('UPDATE users SET consent_form = ? WHERE id=?', [csf, id], async (error, results) => {
                //         if (error) {
                //             console.log(error);
                //         }
                //         else {

                //             res.redirect('/discalproc');
                //         }

                //     });

                // }
                // else {
                //     db.query('UPDATE users SET consent_form = ? WHERE id=?', [csf, id], async (error, results) => {
                //         if (error) {
                //             console.log(error);
                //         }
                //         else {

                //             res.redirect('/asd')
                //         }

                //     });
                // }
                db.query('UPDATE users SET consent_form = ? WHERE id=?', [csf, id], async (error, results) => {
                    if (error) {
                        console.log(error);
                    }
                    else {

                        res.redirect('/discalproc')
                    }

                });




            }

        });






    }


    else {
        res.render('login', {
            message: 'Please login to Access this page!'
        });
    }

}

exports.ssd = (req, res) => {
    if (req.isAuthenticated) {
        var id = req.session.passport.user;
        id = id[1];
        const adu = JSON.stringify(req.body);


        db.query('SELECT * FROM users WHERE id=?', [id], async (error, results) => {
            if (error) {
                console.log(error);
            }
            else {


                db.query('UPDATE users SET ADD_SUBJECT_DETAILS= ? WHERE id=?', [adu, id], async (error, results) => {
                    if (error) {
                        console.log(error);
                    }
                    else {

                        res.redirect('/studyinterface');
                    }

                });






            }
        });

    }
    else {
        res.render('login', {
            message: 'Please login to Access this page!'
        });
    }
}


exports.getfirstsessionlist = (req, res) => {
    res.redirect('/firstsession');

}
exports.getsecondsessionlist = (req, res) => {
    if (req.isAuthenticated) {
        var id = req.session.passport.user;
        id = id[1];

        db.query('SELECT * FROM users WHERE id=?', [id], async (error, results) => {
            if (error) {
                console.log(error);
            }
            else {
                var imglist = JSON.parse(results[0].IMAGE_LIST);
                fslist = imglist.FIRST_SESSION_IMAGE_LIST;

                var unseen_img_list = [];
                for (var i in _.range(Object.entries(fslist).length)) {


                    if (fslist[i].seen_status == 0) {

                        unseen_img_list.push(fslist[i].image_name);

                    }
                }
                if (unseen_img_list.length > 0) {
                    res.redirect('/studyinterface')

                }
                else {
                    res.redirect('/secondsession')
                }



            }


        });
    }
    else {
        res.render('login', {
            message: 'Please login to Access this page!'
        });
    }
}

exports.nexttl1img = (req, res) => {
    if (req.isAuthenticated) {
        var id = req.session.passport.user;
        id = id[1];
        // console.log(req.body);
        var image_name = req.body.image_name;
        if (image_name.includes("\\")) {
            image_name = image_name.split('\\')[1];
        }

        var rating = req.body.rating;
        // console.log(image_name);
        // console.log(rating);

        db.query('SELECT * FROM users WHERE id=?', [id], async (error, results) => {
            if (error) {
                console.log(error);
            }
            else {

                var unseen_tl_list = [];
                var imglist = JSON.parse(results[0].IMAGE_LIST);

                var fslist = imglist.FIRST_SESSION_IMAGE_LIST;
                var sslist = imglist.SECOND_SESSION_IMAGE_LIST;

                var tlist = imglist.TRAINING_IMAGE_LIST;

                for (var i in _.range(Object.entries(tlist).length)) {


                    if (tlist[i].image_name == image_name) {
                        var index = i;
                    }
                    if (tlist[i].rating == -99) {

                        unseen_tl_list.push(tlist[i].image_name);

                    }



                }

                if (tlist[index].rating == -99) {
                    tlist[index].rating = rating;
                    tlist[index].seen_status = 1;
                    console.log(tlist[index]);
                    var Firstsessionobj = _.extend({}, fslist);
                    var trainingobj = _.extend({}, tlist);
                    var Secondsessionobj = _.extend({}, sslist);
                    upimglist = { "TRAINING_IMAGE_LIST": trainingobj, "FIRST_SESSION_IMAGE_LIST": Firstsessionobj, "SECOND_SESSION_IMAGE_LIST": Secondsessionobj }

                    var upimglist = JSON.stringify(upimglist);
                    db.query('UPDATE users SET IMAGE_LIST=? WHERE id=?', [upimglist, id], async (error, results) => {

                        if (error) {
                            console.log(error);
                        }
                        else {


                            console.log("update successful");
                        }
                    })
                }
                // console.log(unseen_tl_list)

                if (unseen_tl_list.length > 1) {
                    console.log(unseen_tl_list[1]);
                    file = unseen_tl_list[1];
                    trainingcomobj = {
                        "0": { "image_name": "00023_00_0.04s.png", "trainingcomment": "This looks picture perfect, with perceptually no significant distortions! How much would you rate it?" },
                        "1": { "image_name": "10161_00_10s_SID_GT_autobrightoff.png", "trainingcomment": "The top right and bottom right portions of the image seem a bit blurred , don't they? Move the slider and click Next to tell us how much you would rate it!" },
                        "2": { "image_name": "FUJI_10161_00_0.1s.png", "trainingcomment": "Looks Blurred , isn't it so?" },
                        "3": { "image_name": "FUJI_10161_00_0.1s_DIDN_he.png", "trainingcomment": "This looks sharper as compared to the previous one , but colours seem to off! What do you think?" },
                        "4": { "image_name": "FUJI_10174_00_0.1s.png", "trainingcomment": "Okay ,here we can actually witness what heavy noise can do to your image! It has even ruined the Color quality of the image " },
                        "5": { "image_name": "FUJI_10174_00_0.1s_DIDN_ldr.png", "trainingcomment": "Though it's a color image, contrast saturation is making it look as though it is grayscale!" },
                        "6": { "image_name": "SONY_00002_00_0.1s_matlabHEon3.png", "trainingcomment": "This is what over enhancement looks like!" },
                        "7": { "image_name": "SONY_10087_00_0.1s_DIDN_ldr.png", "trainingcomment": "Can't see much? Well this is an example of under enhancement!" }
                    }

                    tempcom = "";
                    for (var i in _.range(Object.entries(trainingcomobj).length)) {


                        if (trainingcomobj[i].image_name.includes(String(file))) {

                            tempcom = tempcom + trainingcomobj[i].trainingcomment;

                        }

                    }
                    send = "\\" + file + "comment:" + tempcom;
                    var encrypted = CryptoJS.AES.encrypt(send, "doesntmatterifyouknowit");

                    res.redirect('/trainingphase1?message=' + encodeURIComponent(encrypted));

                    // res.render('trainingphase1', {
                    //     message: send
                    // });
                }
                else {
                    res.redirect('/firstsession')

                }





            }
        });

    }
    else {
        res.render('login', {
            message: 'Please login to Access this page!'
        });
    }


}

exports.nexttl2img = (req, res) => {
    if (req.isAuthenticated) {
        var id = req.session.passport.user;
        id = id[1];
        // console.log(req.body);
        var image_name = req.body.image_name;
        if (image_name.includes("\\")) {
            image_name = image_name.split('\\')[1];
        }

        var rating = req.body.rating;
        // console.log(image_name);
        // console.log(rating);

        db.query('SELECT * FROM users WHERE id=?', [id], async (error, results) => {
            if (error) {
                console.log(error);
            }
            else {

                var unseen_tl_list = [];
                var imglist = JSON.parse(results[0].IMAGE_LIST);

                var fslist = imglist.FIRST_SESSION_IMAGE_LIST;
                var sslist = imglist.SECOND_SESSION_IMAGE_LIST;

                var tlist = imglist.TRAINING_IMAGE_LIST;

                for (var i in _.range(Object.entries(tlist).length)) {


                    if (tlist[i].image_name == image_name) {
                        var index = i;
                    }
                    if (tlist[i].rating_2 == -99) {

                        unseen_tl_list.push(tlist[i].image_name);

                    }



                }

                if (tlist[index].rating_2 == -99) {
                    tlist[index].rating_2 = rating;
                    tlist[index].seen_status = 2;
                    console.log(tlist[index]);
                    var Firstsessionobj = _.extend({}, fslist);
                    var trainingobj = _.extend({}, tlist);
                    var Secondsessionobj = _.extend({}, sslist);
                    upimglist = { "TRAINING_IMAGE_LIST": trainingobj, "FIRST_SESSION_IMAGE_LIST": Firstsessionobj, "SECOND_SESSION_IMAGE_LIST": Secondsessionobj }

                    var upimglist = JSON.stringify(upimglist);
                    db.query('UPDATE users SET IMAGE_LIST=? WHERE id=?', [upimglist, id], async (error, results) => {

                        if (error) {
                            console.log(error);
                        }
                        else {


                            console.log("update successful");
                        }
                    })
                }
                // console.log(unseen_tl_list)

                if (unseen_tl_list.length > 1) {

                    file = unseen_tl_list[1];
                    trainingcomobj = {
                        "0": { "image_name": "00023_00_0.04s.png", "trainingcomment": "This looks picture perfect, with perceptually no significant distortions! How much would you rate it?" },
                        "1": { "image_name": "10161_00_10s_SID_GT_autobrightoff.png", "trainingcomment": "The top right and bottom right portions of the image seem a bit blurred , don't they? Move the slider and click Next to tell us how much you would rate it!" },
                        "2": { "image_name": "FUJI_10161_00_0.1s.png", "trainingcomment": "Looks Blurred , isn't it so?" },
                        "3": { "image_name": "FUJI_10161_00_0.1s_DIDN_he.png", "trainingcomment": "This looks sharper as compared to the previous one , but colours seem to off! What do you think?" },
                        "4": { "image_name": "FUJI_10174_00_0.1s.png", "trainingcomment": "Okay ,here we can actually witness what heavy noise can do to your image! It has even ruined the Color quality of the image " },
                        "5": { "image_name": "FUJI_10174_00_0.1s_DIDN_ldr.png", "trainingcomment": "Though it's a color image, contrast saturation is making it look as though it is grayscale!" },
                        "6": { "image_name": "SONY_00002_00_0.1s_matlabHEon3.png", "trainingcomment": "This is what over enhancement looks like!" },
                        "7": { "image_name": "SONY_10087_00_0.1s_DIDN_ldr.png", "trainingcomment": "Can't see much? Well this is an example of under enhancement!" }
                    }

                    tempcom = "";
                    for (var i in _.range(Object.entries(trainingcomobj).length)) {


                        if (trainingcomobj[i].image_name.includes(String(file))) {

                            tempcom = tempcom + trainingcomobj[i].trainingcomment;

                        }

                    }
                    send = "\\" + file + "comment:" + tempcom;

                    // res.render('trainingphase2', {
                    //     message: send
                    // });
                    var encrypted = CryptoJS.AES.encrypt(send, "doesntmatterifyouknowit");
                    res.redirect('/trainingphase2?message=' + encodeURIComponent(encrypted));
                }
                else {
                    res.redirect('/secondsession')

                }





            }
        });

    }
    else {
        res.render('login', {
            message: 'Please login to Access this page!'
        });
    }


}






exports.nextfsimg = (req, res) => {
    if (req.isAuthenticated) {
        var id = req.session.passport.user;
        id = id[1];
        console.log(req.body);
        var image_name = req.body.image_name;
        if (image_name.includes("\\")) {
            image_name = image_name.split('\\')[1];
        }

        var rating = req.body.rating;
        // console.log(image_name);
        // console.log(rating);

        db.query('SELECT * FROM users WHERE id=?', [id], async (error, results) => {
            if (error) {
                console.log(error);
            }
            else {

                var unseen_fs_list = [];
                var imglist = JSON.parse(results[0].IMAGE_LIST);

                var fslist = imglist.FIRST_SESSION_IMAGE_LIST;
                var sslist = imglist.SECOND_SESSION_IMAGE_LIST;

                var tlist = imglist.TRAINING_IMAGE_LIST;

                for (var i in _.range(Object.entries(fslist).length)) {


                    if (fslist[i].image_name == image_name) {
                        var index = i;
                    }
                    if (fslist[i].seen_status == 0) {

                        unseen_fs_list.push(fslist[i].image_name);

                    }



                }

                if (fslist[index].seen_status == 0) {
                    fslist[index].rating = rating;
                    fslist[index].seen_status = 1;
                    console.log(fslist[index]);
                    var Firstsessionobj = _.extend({}, fslist);
                    var trainingobj = _.extend({}, tlist);
                    var Secondsessionobj = _.extend({}, sslist);
                    upimglist = { "TRAINING_IMAGE_LIST": trainingobj, "FIRST_SESSION_IMAGE_LIST": Firstsessionobj, "SECOND_SESSION_IMAGE_LIST": Secondsessionobj }

                    var upimglist = JSON.stringify(upimglist);
                    db.query('UPDATE users SET IMAGE_LIST=? WHERE id=?', [upimglist, id], async (error, results) => {

                        if (error) {
                            console.log(error);
                        }
                        else {


                            console.log("update successful");
                        }
                    })
                }
                // console.log(unseen_tl_list)

                if (unseen_fs_list.length > 1) {
                    // console.log(unseen_fs_list[1]);
                    file = "\\" + unseen_fs_list[1];
                    console.log(String(Object.entries(fslist).length - unseen_fs_list.length) + "/" + String(Object.entries(fslist).length));
                    send = file + "unseen:" + String(unseen_fs_list.length) + "total:" + String(Object.entries(fslist).length) + "uname:" + String(results[0].name);


                    // res.render('firstsession', {
                    //     message: send
                    // });
                    var encrypted = CryptoJS.AES.encrypt(send, "doesntmatterifyouknowit");
                    res.redirect('/firstsession?message=' + encodeURIComponent(encrypted));
                }
                else {
                    db.query('UPDATE users SET fscstamp=CURRENT_TIMESTAMP WHERE id=?', [id], async (error, results) => {

                        if (error) {
                            console.log(error);
                        }
                        else {


                            console.log("Timestamp added");
                        }
                    })

                    return res.render('studyinterface', {
                        message: "Thank you , you have successfully completed the first session of the study!"
                    });

                }





            }
        });

    }
    else {
        res.render('login', {
            message: 'Please login to Access this page!'
        });
    }


}



exports.nextssimg = (req, res) => {
    if (req.isAuthenticated) {
        var id = req.session.passport.user;
        id = id[1];
        // console.log(req.body);
        var image_name = req.body.image_name;
        if (image_name.includes("\\")) {
            image_name = image_name.split('\\')[1];
        }

        var rating = req.body.rating;
        // console.log(image_name);
        // console.log(rating);

        db.query('SELECT * FROM users WHERE id=?', [id], async (error, results) => {
            if (error) {
                console.log(error);
            }
            else {

                var unseen_ss_list = [];
                var imglist = JSON.parse(results[0].IMAGE_LIST);

                var fslist = imglist.FIRST_SESSION_IMAGE_LIST;
                var sslist = imglist.SECOND_SESSION_IMAGE_LIST;

                var tlist = imglist.TRAINING_IMAGE_LIST;

                for (var i in _.range(Object.entries(sslist).length)) {


                    if (sslist[i].image_name == image_name) {
                        var index = i;
                    }
                    if (sslist[i].seen_status == 0) {

                        unseen_ss_list.push(sslist[i].image_name);

                    }



                }

                if (sslist[index].seen_status == 0) {
                    sslist[index].rating = rating;
                    sslist[index].seen_status = 1;
                    console.log(sslist[index]);
                    var Firstsessionobj = _.extend({}, fslist);
                    var trainingobj = _.extend({}, tlist);
                    var Secondsessionobj = _.extend({}, sslist);
                    upimglist = { "TRAINING_IMAGE_LIST": trainingobj, "FIRST_SESSION_IMAGE_LIST": Firstsessionobj, "SECOND_SESSION_IMAGE_LIST": Secondsessionobj }

                    var upimglist = JSON.stringify(upimglist);
                    db.query('UPDATE users SET IMAGE_LIST=? WHERE id=?', [upimglist, id], async (error, results) => {

                        if (error) {
                            console.log(error);
                        }
                        else {


                            console.log("update successful");
                        }
                    })
                }
                // console.log(unseen_tl_list)

                if (unseen_ss_list.length > 1) {
                    console.log(unseen_ss_list[1]);
                    file = "\\" + unseen_ss_list[1];
                    console.log(String(Object.entries(sslist).length - unseen_ss_list.length) + "/" + String(Object.entries(sslist).length));
                    send = file + "unseen:" + String(unseen_ss_list.length) + "total:" + String(Object.entries(sslist).length) + "uname:" + String(results[0].name);


                    // res.render('secondsession', {
                    //     message: send
                    // });
                    var encrypted = CryptoJS.AES.encrypt(send, "doesntmatterifyouknowit");
                    res.redirect('/secondsession?message=' + encodeURIComponent(encrypted));
                }
                else {


                    res.render('studyinterface', {
                        message: "Thank you , you have successfully completed the Second session of the study!"
                    });

                }





            }
        });

    }
    else {
        res.render('login', {
            message: 'Please login to Access this page!'
        });
    }


}
exports.gotoinst = (req, res) => {
    if (req.isAuthenticated) {
        var id = req.session.passport.user;
        id = id[1];
        const adu = JSON.stringify(req.body);
        db.query('SELECT * FROM users WHERE id=?', [id], async (error, results) => {
            if (error) {
                console.log(error);
            }
            else {
                if (results[0].ADD_SUBJECT_DETAILS != null) {
                    res.redirect('/studyinterface');

                }
                else {
                    res.redirect('/asd');
                }

            }
        });
    }
    else {
        res.render('login', {
            message: 'Please login to Access this page!'
        });
    }
}

// 

exports.ssd2 = (req, res) => {
    if (req.isAuthenticated) {
        var id = req.session.passport.user;
        id = id[1];
        const adu2 = req.body;


        db.query('SELECT * FROM users WHERE id=?', [id], async (error, results) => {
            if (error) {
                console.log(error);
            }
            else {
                console.log("ASD2")
                var adu = JSON.parse(results[0].ADD_SUBJECT_DETAILS)
                ADU = Object.assign({}, adu, adu2)

                ADU = JSON.stringify(ADU)


                db.query('UPDATE users SET ADD_SUBJECT_DETAILS= ? WHERE id=?', [ADU, id], async (error, results) => {
                    if (error) {
                        console.log(error);
                    }
                    else {

                        res.redirect('/trainingphase2');
                    }

                });






            }
        });

    }
    else {
        res.render('login', {
            message: 'Please login to Access this page!'
        });
    }
}