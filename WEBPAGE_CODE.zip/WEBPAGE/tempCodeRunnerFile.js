const mysql = require("mysql");
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const emailexist = require("email-existence");
const nodemailer = require("nodemailer");
var passport = require('passport');
let jsonimglist = require('D:/RESEARCHWORK/WEBBBPAGE/mine/mysubjectivestudy/testmodchangeauthtojquery/finalimglist.json');
// console.log(json, 'the json obj');
//requiring path and fs modules
const dotenv = require('dotenv');                                /****imp env variables */
dotenv.config({ path: './.env' });
const path = require('path');
const fs = require('fs');
var _ = require('lodash');
const { stringify } = require('querystring');
const { concat } = require('lodash');
const { json } = require("express");

//joining path of directory 
const publicip = 'http://localhost:3000';
const verport = publicip + '/verify';
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.NODEMAIL_USER,
        pass: process.env.NODEMAIL_PASSWORD,
    },
});



const db = mysql.createConnection({
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE

});
const trainingpath = path.join(__dirname, '/TRAINING_IMAGES/');
var trainingimages = fs.readdirSync(trainingpath, { withFileTypes: true })
    .filter(item => !item.isDirectory())
    .map(item => item.name);
const timer = ms => new Promise(res => setTimeout(res, ms))

fss = [];
sss = [];
for (const [index, element] of Object.entries(jsonimglist)) {
    if (index % 2 == 0) {
        fss.push(element)
    }
    else {
        sss.push(element)
    }
}
fss = Object.assign({}, fss);
sss = Object.assign({}, sss);
function clean(obj) {
    for (var propName in obj) {
        if (obj[propName] === null || obj[propName] === undefined || obj[propName] === "") {
            delete obj[propName];
        }
    }
}

for (const [index, element] of Object.entries(fss)) {
    clean(element)
}
for (const [index, element] of Object.entries(sss)) {
    clean(element)
}
console.log(sss)